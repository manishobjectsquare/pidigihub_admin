import React from 'react'

const DepartmentAdd = () => {
    return (
        <div>DepartmentAdd</div>
    )
}

export default DepartmentAdd