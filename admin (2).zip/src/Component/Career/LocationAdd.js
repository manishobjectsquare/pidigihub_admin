import React from 'react'

const LocationAdd = () => {
    return (
        <div>LocationAdd</div>
    )
}

export default LocationAdd